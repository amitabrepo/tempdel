*****How to install and execute tests*****

Pre-req:
1: Node-js [Latest version]
2: VS Code

Installation & Execution:
--Open terminal and enter following commands from root of folder--

1: npm install
2: npm run api-test

Test code:
cypress\e2e\spec.cy.js