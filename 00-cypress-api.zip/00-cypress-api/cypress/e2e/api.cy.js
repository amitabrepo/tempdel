describe('API TEST', () => {
  const apiURL = 'https://odegdcpnma.execute-api.eu-west-2.amazonaws.com/development/prices'

  it('01-ensure api is live', () => {
    cy.request(apiURL + '?dno=10&voltage=HV&start=01-06-2021&end=03-06-2021').its('status').should('eq', 200)
  })

  it('02-ensuring api returns data with parameters', () => {
    cy.request({
      method: 'GET',
      url: apiURL,
      qs: {
        dno: 10,
        voltage: 'HV',
        start: '01-06-2021',
        end: '03-06-2021'
      }
    }).as('test2')

    cy.get('@test2').its('status').should('eq', 200)
    cy.get('@test2').then(resData => {
      expect(resData.body.data.data[0].Overall.toString().length).to.be.greaterThan(0)
      expect(resData.body.data.data[0].unixTimestamp.toString().length).to.be.greaterThan(0)
      expect(resData.body.data.data[0].Timestamp.toString().length).to.be.greaterThan(0)
    })
  })

  it('03-api fails when mandatory parameters are omitted', () => {

    cy.request({
      method: 'GET',
      url: apiURL,
      qs: {
        dno: 10,
        voltage: 'HV',
        start: '01-06-2021'
        //,
        // end: '03-06-2021'
      }
    }).as('test3')

    cy.get('@test3').its('status').should('eq', 200)
    cy.get('@test3').then(resData => {
      expect(resData.body.errorMessage).to.be.eq(`time data '' does not match format '%d-%m-%Y'`)
    })
  })
})